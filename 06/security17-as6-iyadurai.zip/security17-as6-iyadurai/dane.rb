require 'dnsruby'

class Dane

  # @param mail [Mail::Message] mail
  def apply!(mail)
  end
end
